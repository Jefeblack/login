﻿Imports System.Data.SqlClient
Public Class conexion
    'Variable para conectarse a la base de Datos
    Public cnn As New SqlConnection
    'Variable para que el usuario pueda interactuar con el menu
    Public idusuario As Integer
    'Funcion para conectarse a la base de Datos 
    Public Function conectado()
        Try
            cnn = New SqlConnection("Server=ABDIEL\ABDIEL;Database=dbventas;integrated security=true")
            cnn.Open()
            Return True
        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        End Try
    End Function
    'Funcion para Desconectarse a la base de Datos
    Public Function desconectado()
        Try
            If cnn.State = ConnectionState.Open Then
                cnn.Close()
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return False
        End Try
    End Function

End Class
