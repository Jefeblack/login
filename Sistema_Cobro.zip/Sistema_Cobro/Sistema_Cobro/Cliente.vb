﻿Imports System.Data
Imports System.Data.SqlClient
Public Class Cliente
    'Variable para la conexion
    Dim con As New SqlConnection(My.Settings.Conexion)
    'para poder aceder al procedimiento almacenado
    Dim cmd As New SqlCommand

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ''conexion a la base de datos
        con = New SqlConnection()
        con.ConnectionString = "Server=ABDIEL\ABDIEL;Database=SisCuen_Cobr;Integrated Security=True;"

        'Para mostrar la Tabla de ALUMNOS
        Dim sql As String = "Select * from Cliente"
        Dim cmd As New SqlCommand(sql, con)
        Dim da As New SqlDataAdapter(cmd)
        Dim ds As New DataSet
        da.Fill(ds, "Cliente")
        Me.DataGridView1.DataSource = ds.Tables("Cliente")
    End Sub

    Private Sub btnInsertar_Click(sender As Object, e As EventArgs) Handles btnInsertar.Click
        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Ingresar_Cliente"
        cmd.Parameters.Add("id_Cliente", SqlDbType.Int).Value = txtIDCliente.Text.Trim()
        cmd.Parameters.Add("Nombre", SqlDbType.NVarChar).Value = txtNombre.Text.Trim()
        cmd.Parameters.Add("Apellido", SqlDbType.NVarChar).Value = txtApellido.Text.Trim()
        cmd.Parameters.Add("Cedula", SqlDbType.NVarChar).Value = txtCedula.Text.Trim()
        cmd.Parameters.Add("Telefono", SqlDbType.NVarChar).Value = txtTelefono.Text.Trim()
        cmd.Parameters.Add("Direccion", SqlDbType.NVarChar).Value = txtDireccion.Text.Trim()
        cmd.Parameters.Add("E_mail", SqlDbType.NVarChar).Value = txtEMail.Text.Trim()
        cmd.Connection = con
        Try
            con.Open()
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Throw ex
        Finally
            con.Close()
            con.Dispose()
        End Try
    End Sub
End Class
