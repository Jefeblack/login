﻿Imports System.Data
Imports System.Data.SqlClient
Public Class Cliente
    'Variable para la conexion
    Dim con As New SqlConnection(My.Settings.Conexion)
    'para poder aceder al procedimiento almacenado
    Dim cmd As New SqlCommand

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ''conexion a la base de datos
        con = New SqlConnection()
        con.ConnectionString = "Server=ABDIEL\ABDIEL;Database=SisCuen_Cobr;Integrated Security=True;"

        'Para mostrar la Tabla de ALUMNOS
        Dim sql As String = "Select * from Cliente"
        Dim cmd As New SqlCommand(sql, con)
        Dim da As New SqlDataAdapter(cmd)
        Dim ds As New DataSet
        da.Fill(ds, "Cliente")
        Me.DataGridView1.DataSource = ds.Tables("Cliente")
    End Sub

    Private Sub btnInsertar_Click(sender As Object, e As EventArgs) Handles btnInsertar.Click
        ''conexion a la base de datos
        con = New SqlConnection(My.Settings.Conexion)
        
        Using (con)
            'para poder aceder al procedimiento almacenado
            Dim cmd As New SqlCommand
            cmd.Connection = con
            cmd.CommandText = "Ingresar_Cliente"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("id_Cliente", SqlDbType.Int).Value = txtIDCliente.Text.Trim()
            cmd.Parameters.Add("Nombre", SqlDbType.NVarChar).Value = txtNombre.Text.Trim()
            cmd.Parameters.Add("Apellido", SqlDbType.NVarChar).Value = txtApellido.Text.Trim()
            cmd.Parameters.Add("Cedula", SqlDbType.NVarChar).Value = txtCedula.Text.Trim()
            cmd.Parameters.Add("Telefono", SqlDbType.NVarChar).Value = txtTelefono.Text.Trim()
            cmd.Parameters.Add("Direccion", SqlDbType.NVarChar).Value = txtDireccion.Text.Trim()
            cmd.Parameters.Add("E_mail", SqlDbType.NVarChar).Value = txtEMail.Text.Trim()
            con.Open()
            cmd.ExecuteNonQuery()
        End Using
        MsgBox("Nuevo Cliente Agregado")
        txtIDCliente.Text = ""
        txtNombre.Text = ""
        txtApellido.Text = ""
        txtCedula.Text = ""
        txtTelefono.Text = ""
        txtDireccion.Text = ""
        txtEMail.Text = ""


    End Sub

    Private Sub btnEditar_Click(sender As Object, e As EventArgs) Handles btnEditar.Click
        ''conexion a la base de datos
        con = New SqlConnection(My.Settings.Conexion)

        Using (con)
            'para poder aceder al procedimiento almacenado
            Dim cmd As New SqlCommand
            cmd.Connection = con
            cmd.CommandText = "Modificar_Cliente"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("id_Cliente", SqlDbType.Int).Value = txtIDCliente.Text.Trim()
            cmd.Parameters.Add("Nombre", SqlDbType.NVarChar).Value = txtNombre.Text.Trim()
            cmd.Parameters.Add("Apellido", SqlDbType.NVarChar).Value = txtApellido.Text.Trim()
            cmd.Parameters.Add("Cedula", SqlDbType.NVarChar).Value = txtCedula.Text.Trim()
            cmd.Parameters.Add("Telefono", SqlDbType.NVarChar).Value = txtTelefono.Text.Trim()
            cmd.Parameters.Add("Direccion", SqlDbType.NVarChar).Value = txtDireccion.Text.Trim()
            cmd.Parameters.Add("E_mail", SqlDbType.NVarChar).Value = txtEMail.Text.Trim()
            con.Open()
            cmd.ExecuteNonQuery()
        End Using
        MsgBox("Ya se realizo los cambios")
        txtIDCliente.Text = ""
        txtNombre.Text = ""
        txtApellido.Text = ""
        txtCedula.Text = ""
        txtTelefono.Text = ""
        txtDireccion.Text = ""
        txtEMail.Text = ""
    End Sub

    Private Sub btnBorrar_Click(sender As Object, e As EventArgs) Handles btnBorrar.Click
        ''conexion a la base de datos
        con = New SqlConnection(My.Settings.Conexion)

        Using (con)
            'para poder aceder al procedimiento almacenado
            Dim cmd As New SqlCommand
            cmd.Connection = con
            cmd.CommandText = "Eliminar_Cliente"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("id_Cliente", SqlDbType.Int).Value = txtIDCliente.Text.Trim()
            con.Open()
            cmd.ExecuteNonQuery()
        End Using
        MsgBox("Ya se Elimino")
    End Sub
End Class
